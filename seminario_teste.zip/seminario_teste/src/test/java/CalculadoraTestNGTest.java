import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CalculadoraTestNGTest {
    private Calculadora calculadora;
    @BeforeMethod
            void prepararCalculadora() {
        calculadora = new Calculadora();
            }
    @Test
    public void deveSomarDoisNumeros() {
        int resultado =
                calculadora.somar(50, 10);
        Assert.assertEquals(resultado, 60);
    }
    @Test
    public void deveSubtrairDoisNumeros() {
        int resultado =
                calculadora.subtrair(50, 10);
                Assert.assertEquals(resultado, 40);
    }
    @Test
    public void deveMultiplicarDoisNumeros() {
        int resultado =
                calculadora.multiplicar(50, 10);
        Assert.assertEquals(resultado, 500);
    }
    @Test
    public void deveDividirDoisNumeros() {
        int resultado =
                calculadora.dividir(50,10);
                Assert.assertEquals(resultado,5);
    }
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void deveImpedirDivisaoPorZero() {
        calculadora.dividir(10, 0);
    }

}
