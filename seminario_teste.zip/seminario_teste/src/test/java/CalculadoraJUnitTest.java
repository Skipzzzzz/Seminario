import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;

public class CalculadoraJUnitTest {
    private Calculadora  calculadora;
    @BeforeEach
    void prepararCalculadora() {
        calculadora = new Calculadora();
    }
    @Test
    void deveDividirDoisNumeros() {
        int resultado =
                calculadora.dividir(50, 10);
        assertEquals(5, resultado);
    }
    @Test
    void deveMultiplicarDoisNumeros() {
        int resultado =
                calculadora.multiplicar(50, 10);
        assertEquals(500, resultado);
    }

    @Test
    void deveSomarDoisNumeros() {
        int resultado =
                calculadora.somar(50, 10);
        assertEquals(60, resultado);
    }

    @Test
    void deveSubtrairDoisNumeros() {
        int resultado =
                calculadora.subtrair(50, 10);
        assertEquals(40, resultado);
    }
    @Test
    void deveImpedirdivisaoPorZero() {
        assertThrows(
                IllegalArgumentException.class,
                () -> calculadora.dividir(50, 0)
        );
    }


}